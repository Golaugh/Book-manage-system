package bookManageSystem.view;

public class ueserdataImpl extends ueserdata {
    ueserdataImpl(String xuehao, String name, String banji) {
        super(xuehao, name, banji);
    }
}
