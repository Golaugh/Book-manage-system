package bookManageSystem.view;

public class ueserdata {
    String xuehao;
    String name;
    String banji;
    ueserdata(String xuehao,String name,String banji){
        this.xuehao=xuehao;
        this.name=name;
        this.banji=banji;
    }
}
